package com.example.bathangban;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText user,password;
    Button dangnhap,dangky,thoat;
    String ten,mk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Anhxa();
        ControlButton();
    }

    private void ControlButton() {
        thoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this,android.R.style.Theme_DeviceDefault_Light_Dialog);
                builder.setTitle("Bạn có chắc muốn thoát khỏi app");
                builder.setMessage("Hãy lựa chọn bên dưới để xác nhận");
                builder.setIcon(android.R.drawable.ic_dialog_alert);
                builder.setPositiveButton("Có ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        onBackPressed();
                    }
                });
                builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });
        dangky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog= new Dialog(MainActivity.this);
                dialog.setTitle("Đăng ký tài khoản");
                dialog.setCancelable(false);
                dialog.setContentView(R.layout.dangnhapdialog);
                final EditText ettaikhoan = (EditText)dialog.findViewById(R.id.ettaikhoan);
                final EditText etmatkhau = (EditText)dialog.findViewById(R.id.etmatkhau);
                Button huy=(Button)dialog.findViewById(R.id.btnhuy);
                Button dongy=(Button)dialog.findViewById(R.id.btndongy);
                dongy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ten=ettaikhoan.getText().toString().trim();
                        mk=etmatkhau.getText().toString().trim();

                        user.setText(ten);
                        password.setText(mk);

                        dialog.cancel();

                    }
                });
                huy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });
                dialog.show();
            }
        });
        dangnhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user.getText().length()!=0 && password.getText().length()!=0){
                    if(user.getText().toString().equals(ten)&&password.getText().toString().equals(mk)){
                        Toast.makeText(MainActivity.this,"Đăng nhập thành công",Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(MainActivity.this,signin.class);
                        startActivity(intent);

                    }else if(user.getText().toString().equals("phat") && password.getText().toString().equals("123")){
                        Toast.makeText(MainActivity.this,"Đăng nhập thành công",Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(MainActivity.this,signin.class);
                        startActivity(intent);
                    }else {
                        Toast.makeText(MainActivity.this,"Đăng nhập không thành công",Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(MainActivity.this,"Mời bạn nhập đủ thông tin",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void Anhxa(){
        user = (EditText)findViewById(R.id.etuser);
        password=(EditText)findViewById(R.id.etpassword);
        dangnhap=(Button)findViewById(R.id.btndangnhap);
        dangky=(Button)findViewById(R.id.btndangky);
        thoat=(Button)findViewById(R.id.btnthoat);
    }
}